This is my react <i> <b> Project for final evaluation at college</b> </i>, I'll try to keep updating the README File as well. Wish me Luck HAHAHA.

<h3>Checkpoint 1</h3>
<ol>
<li>
<p>Navbar is done
</p>
</li>

<h3>Checkpoint 2</h3>
<li>
   <p> Done with the Hero Section.</p>
</li>
<li>
<p>    Done with the Services Part</p>
</li>

<h3>Checkpoint 3</h3>
<li>
<p>
    Review Section Done
</p>
</li>
<li>
Added TS particles looks good 
</li>
<li>
Projects Section Done
</li>
<li>News Section Done</li>
<li>Project Completed</li>
<li>Gonna try to add animations let's see</li>
<li>Last Commit on Readme Hope So</li>
</ol>
